
user/_mytest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <check>:

int passed = 0;
int failed = 0;

void check(const char *test, int actual, int expected)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
   8:	86ae                	mv	a3,a1
  if (actual == expected) {
   a:	02c58463          	beq	a1,a2,32 <check+0x32>
    printf("[PASS] %s : got %d\n", test, actual);
    passed++;
  } else {
    printf("[FAIL] %s : expected %d, got %d\n", test, expected, actual);
   e:	85aa                	mv	a1,a0
  10:	00001517          	auipc	a0,0x1
  14:	bf850513          	addi	a0,a0,-1032 # c08 <malloc+0x118>
  18:	225000ef          	jal	a3c <printf>
    failed++;
  1c:	00002717          	auipc	a4,0x2
  20:	fe470713          	addi	a4,a4,-28 # 2000 <failed>
  24:	431c                	lw	a5,0(a4)
  26:	2785                	addiw	a5,a5,1
  28:	c31c                	sw	a5,0(a4)
  }
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret
    printf("[PASS] %s : got %d\n", test, actual);
  32:	862e                	mv	a2,a1
  34:	85aa                	mv	a1,a0
  36:	00001517          	auipc	a0,0x1
  3a:	bba50513          	addi	a0,a0,-1094 # bf0 <malloc+0x100>
  3e:	1ff000ef          	jal	a3c <printf>
    passed++;
  42:	00002717          	auipc	a4,0x2
  46:	fc270713          	addi	a4,a4,-62 # 2004 <passed>
  4a:	431c                	lw	a5,0(a4)
  4c:	2785                	addiw	a5,a5,1
  4e:	c31c                	sw	a5,0(a4)
  50:	bfe9                	j	2a <check+0x2a>

0000000000000052 <main>:

int main()
{
  52:	1141                	addi	sp,sp,-16
  54:	e406                	sd	ra,8(sp)
  56:	e022                	sd	s0,0(sp)
  58:	0800                	addi	s0,sp,16
  int ret;

  printf("[INFO] init(pid 1) and sh(pid 2) are created during boot.\n");
  5a:	00001517          	auipc	a0,0x1
  5e:	bd650513          	addi	a0,a0,-1066 # c30 <malloc+0x140>
  62:	1db000ef          	jal	a3c <printf>
  printf("[INFO] mytest(pid 3) should be the current test program.\n");
  66:	00001517          	auipc	a0,0x1
  6a:	c0a50513          	addi	a0,a0,-1014 # c70 <malloc+0x180>
  6e:	1cf000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Current Process State ==========\n");
  72:	00001517          	auipc	a0,0x1
  76:	c3e50513          	addi	a0,a0,-962 # cb0 <malloc+0x1c0>
  7a:	1c3000ef          	jal	a3c <printf>
  // ============================================================
  printf("[INFO] The following processes are already running:\n");
  7e:	00001517          	auipc	a0,0x1
  82:	c6250513          	addi	a0,a0,-926 # ce0 <malloc+0x1f0>
  86:	1b7000ef          	jal	a3c <printf>
  ps(0);
  8a:	4501                	li	a0,0
  8c:	610000ef          	jal	69c <ps>
  printf("\n");
  90:	00001517          	auipc	a0,0x1
  94:	c8850513          	addi	a0,a0,-888 # d18 <malloc+0x228>
  98:	1a5000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Testing getnice() ==========\n");
  9c:	00001517          	auipc	a0,0x1
  a0:	c8450513          	addi	a0,a0,-892 # d20 <malloc+0x230>
  a4:	199000ef          	jal	a3c <printf>
  // ============================================================

  // pid 1 (init) exists, default nice = 20
  ret = getnice(1);
  a8:	4505                	li	a0,1
  aa:	5e2000ef          	jal	68c <getnice>
  ae:	85aa                	mv	a1,a0
  check("getnice(1) - init default nice", ret, 20);
  b0:	4651                	li	a2,20
  b2:	00001517          	auipc	a0,0x1
  b6:	c9e50513          	addi	a0,a0,-866 # d50 <malloc+0x260>
  ba:	f47ff0ef          	jal	0 <check>

  // pid 2 (sh) exists, default nice = 20
  ret = getnice(2);
  be:	4509                	li	a0,2
  c0:	5cc000ef          	jal	68c <getnice>
  c4:	85aa                	mv	a1,a0
  check("getnice(2) - sh default nice", ret, 20);
  c6:	4651                	li	a2,20
  c8:	00001517          	auipc	a0,0x1
  cc:	ca850513          	addi	a0,a0,-856 # d70 <malloc+0x280>
  d0:	f31ff0ef          	jal	0 <check>

  // pid 12 does not exist → should return -1
  ret = getnice(12);
  d4:	4531                	li	a0,12
  d6:	5b6000ef          	jal	68c <getnice>
  da:	85aa                	mv	a1,a0
  check("getnice(12) - no such process", ret, -1);
  dc:	567d                	li	a2,-1
  de:	00001517          	auipc	a0,0x1
  e2:	cb250513          	addi	a0,a0,-846 # d90 <malloc+0x2a0>
  e6:	f1bff0ef          	jal	0 <check>

  printf("\n");
  ea:	00001517          	auipc	a0,0x1
  ee:	c2e50513          	addi	a0,a0,-978 # d18 <malloc+0x228>
  f2:	14b000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Testing setnice() ==========\n");
  f6:	00001517          	auipc	a0,0x1
  fa:	cba50513          	addi	a0,a0,-838 # db0 <malloc+0x2c0>
  fe:	13f000ef          	jal	a3c <printf>
  // ============================================================

  // Set nice of pid 1 (init) to 10 → should succeed (return 0)
  ret = setnice(1, 10);
 102:	45a9                	li	a1,10
 104:	4505                	li	a0,1
 106:	58e000ef          	jal	694 <setnice>
 10a:	85aa                	mv	a1,a0
  check("setnice(1, 10) - valid", ret, 0);
 10c:	4601                	li	a2,0
 10e:	00001517          	auipc	a0,0x1
 112:	cd250513          	addi	a0,a0,-814 # de0 <malloc+0x2f0>
 116:	eebff0ef          	jal	0 <check>

  // Verify the change
  ret = getnice(1);
 11a:	4505                	li	a0,1
 11c:	570000ef          	jal	68c <getnice>
 120:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 10", ret, 10);
 122:	4629                	li	a2,10
 124:	00001517          	auipc	a0,0x1
 128:	cd450513          	addi	a0,a0,-812 # df8 <malloc+0x308>
 12c:	ed5ff0ef          	jal	0 <check>

  // Restore to default
  ret = setnice(1, 20);
 130:	45d1                	li	a1,20
 132:	4505                	li	a0,1
 134:	560000ef          	jal	694 <setnice>
 138:	85aa                	mv	a1,a0
  check("setnice(1, 20) - restore default", ret, 0);
 13a:	4601                	li	a2,0
 13c:	00001517          	auipc	a0,0x1
 140:	ce450513          	addi	a0,a0,-796 # e20 <malloc+0x330>
 144:	ebdff0ef          	jal	0 <check>

  // pid 12 does not exist → should return -1
  ret = setnice(12, 10);
 148:	45a9                	li	a1,10
 14a:	4531                	li	a0,12
 14c:	548000ef          	jal	694 <setnice>
 150:	85aa                	mv	a1,a0
  check("setnice(12, 10) - no such process", ret, -1);
 152:	567d                	li	a2,-1
 154:	00001517          	auipc	a0,0x1
 158:	cf450513          	addi	a0,a0,-780 # e48 <malloc+0x358>
 15c:	ea5ff0ef          	jal	0 <check>

  // nice value 40 is out of range (valid: 0–39) → should return -1
  ret = setnice(1, 40);
 160:	02800593          	li	a1,40
 164:	4505                	li	a0,1
 166:	52e000ef          	jal	694 <setnice>
 16a:	85aa                	mv	a1,a0
  check("setnice(1, 40) - invalid nice value", ret, -1);
 16c:	567d                	li	a2,-1
 16e:	00001517          	auipc	a0,0x1
 172:	d0250513          	addi	a0,a0,-766 # e70 <malloc+0x380>
 176:	e8bff0ef          	jal	0 <check>

  // nice value -1 is out of range → should return -1
  ret = setnice(1, -1);
 17a:	55fd                	li	a1,-1
 17c:	4505                	li	a0,1
 17e:	516000ef          	jal	694 <setnice>
 182:	85aa                	mv	a1,a0
  check("setnice(1, -1) - negative nice value", ret, -1);
 184:	567d                	li	a2,-1
 186:	00001517          	auipc	a0,0x1
 18a:	d1250513          	addi	a0,a0,-750 # e98 <malloc+0x3a8>
 18e:	e73ff0ef          	jal	0 <check>

  printf("\n");
 192:	00001517          	auipc	a0,0x1
 196:	b8650513          	addi	a0,a0,-1146 # d18 <malloc+0x228>
 19a:	0a3000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Testing ps() ==========\n");
 19e:	00001517          	auipc	a0,0x1
 1a2:	d2250513          	addi	a0,a0,-734 # ec0 <malloc+0x3d0>
 1a6:	097000ef          	jal	a3c <printf>
  // ============================================================

  // ps(0) prints all processes — verify visually
  printf("[INFO] ps(0) - should print all processes (init, sh, mytest):\n");
 1aa:	00001517          	auipc	a0,0x1
 1ae:	d3e50513          	addi	a0,a0,-706 # ee8 <malloc+0x3f8>
 1b2:	08b000ef          	jal	a3c <printf>
  ps(0);
 1b6:	4501                	li	a0,0
 1b8:	4e4000ef          	jal	69c <ps>
  printf("\n");
 1bc:	00001517          	auipc	a0,0x1
 1c0:	b5c50513          	addi	a0,a0,-1188 # d18 <malloc+0x228>
 1c4:	079000ef          	jal	a3c <printf>

  // ps(1) prints only init
  printf("[INFO] ps(1) - should print only init:\n");
 1c8:	00001517          	auipc	a0,0x1
 1cc:	d6050513          	addi	a0,a0,-672 # f28 <malloc+0x438>
 1d0:	06d000ef          	jal	a3c <printf>
  ps(1);
 1d4:	4505                	li	a0,1
 1d6:	4c6000ef          	jal	69c <ps>
  printf("\n");
 1da:	00001517          	auipc	a0,0x1
 1de:	b3e50513          	addi	a0,a0,-1218 # d18 <malloc+0x228>
 1e2:	05b000ef          	jal	a3c <printf>

  // ps(12) — no such process, should print nothing
  printf("[INFO] ps(12) - no such process, should print nothing:\n");
 1e6:	00001517          	auipc	a0,0x1
 1ea:	d6a50513          	addi	a0,a0,-662 # f50 <malloc+0x460>
 1ee:	04f000ef          	jal	a3c <printf>
  ps(12);
 1f2:	4531                	li	a0,12
 1f4:	4a8000ef          	jal	69c <ps>
  printf("[INFO] (no output expected above)\n");
 1f8:	00001517          	auipc	a0,0x1
 1fc:	d9050513          	addi	a0,a0,-624 # f88 <malloc+0x498>
 200:	03d000ef          	jal	a3c <printf>

  printf("\n");
 204:	00001517          	auipc	a0,0x1
 208:	b1450513          	addi	a0,a0,-1260 # d18 <malloc+0x228>
 20c:	031000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Testing meminfo() ==========\n");
 210:	00001517          	auipc	a0,0x1
 214:	da050513          	addi	a0,a0,-608 # fb0 <malloc+0x4c0>
 218:	025000ef          	jal	a3c <printf>
  // ============================================================

  uint64 mem = meminfo();
 21c:	488000ef          	jal	6a4 <meminfo>
  if (mem > 0) {
 220:	c131                	beqz	a0,264 <main+0x212>
 222:	85aa                	mv	a1,a0
    printf("[PASS] meminfo() - free memory: %lu bytes\n", mem);
 224:	00001517          	auipc	a0,0x1
 228:	dbc50513          	addi	a0,a0,-580 # fe0 <malloc+0x4f0>
 22c:	011000ef          	jal	a3c <printf>
    passed++;
 230:	00002717          	auipc	a4,0x2
 234:	dd470713          	addi	a4,a4,-556 # 2004 <passed>
 238:	431c                	lw	a5,0(a4)
 23a:	2785                	addiw	a5,a5,1
 23c:	c31c                	sw	a5,0(a4)
  } else {
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
    failed++;
  }

  printf("\n");
 23e:	00001517          	auipc	a0,0x1
 242:	ada50513          	addi	a0,a0,-1318 # d18 <malloc+0x228>
 246:	7f6000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Testing waitpid() ==========\n");
 24a:	00001517          	auipc	a0,0x1
 24e:	df650513          	addi	a0,a0,-522 # 1040 <malloc+0x550>
 252:	7ea000ef          	jal	a3c <printf>
  // Note: waitpid suspends execution until a specific process terminates.
  // To test this, we use fork() to create child processes that exit immediately,
  // then verify that waitpid correctly waits for them.

  // Test 1: fork a child, then waitpid for it
  int pid1 = fork();
 256:	38e000ef          	jal	5e4 <fork>
  if (pid1 < 0) {
 25a:	02054463          	bltz	a0,282 <main+0x230>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid1 == 0) {
 25e:	e121                	bnez	a0,29e <main+0x24c>
    // child process — exit immediately
    exit(0);
 260:	38c000ef          	jal	5ec <exit>
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
 264:	4581                	li	a1,0
 266:	00001517          	auipc	a0,0x1
 26a:	daa50513          	addi	a0,a0,-598 # 1010 <malloc+0x520>
 26e:	7ce000ef          	jal	a3c <printf>
    failed++;
 272:	00002717          	auipc	a4,0x2
 276:	d8e70713          	addi	a4,a4,-626 # 2000 <failed>
 27a:	431c                	lw	a5,0(a4)
 27c:	2785                	addiw	a5,a5,1
 27e:	c31c                	sw	a5,0(a4)
 280:	bf7d                	j	23e <main+0x1ec>
    printf("[FAIL] fork() failed\n");
 282:	00001517          	auipc	a0,0x1
 286:	dee50513          	addi	a0,a0,-530 # 1070 <malloc+0x580>
 28a:	7b2000ef          	jal	a3c <printf>
    failed++;
 28e:	00002717          	auipc	a4,0x2
 292:	d7270713          	addi	a4,a4,-654 # 2000 <failed>
 296:	431c                	lw	a5,0(a4)
 298:	2785                	addiw	a5,a5,1
 29a:	c31c                	sw	a5,0(a4)
 29c:	a819                	j	2b2 <main+0x260>
  } else {
    // parent — wait for pid1 to terminate
    ret = waitpid(pid1);
 29e:	40e000ef          	jal	6ac <waitpid>
 2a2:	85aa                	mv	a1,a0
    check("waitpid(pid1) - child exited", ret, 0);
 2a4:	4601                	li	a2,0
 2a6:	00001517          	auipc	a0,0x1
 2aa:	de250513          	addi	a0,a0,-542 # 1088 <malloc+0x598>
 2ae:	d53ff0ef          	jal	0 <check>
  }

  // Test 2: fork another child, waitpid for it
  int pid2 = fork();
 2b2:	332000ef          	jal	5e4 <fork>
  if (pid2 < 0) {
 2b6:	00054563          	bltz	a0,2c0 <main+0x26e>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid2 == 0) {
 2ba:	e10d                	bnez	a0,2dc <main+0x28a>
    // child process — exit immediately
    exit(0);
 2bc:	330000ef          	jal	5ec <exit>
    printf("[FAIL] fork() failed\n");
 2c0:	00001517          	auipc	a0,0x1
 2c4:	db050513          	addi	a0,a0,-592 # 1070 <malloc+0x580>
 2c8:	774000ef          	jal	a3c <printf>
    failed++;
 2cc:	00002717          	auipc	a4,0x2
 2d0:	d3470713          	addi	a4,a4,-716 # 2000 <failed>
 2d4:	431c                	lw	a5,0(a4)
 2d6:	2785                	addiw	a5,a5,1
 2d8:	c31c                	sw	a5,0(a4)
 2da:	a819                	j	2f0 <main+0x29e>
  } else {
    // parent — wait for pid2 to terminate
    ret = waitpid(pid2);
 2dc:	3d0000ef          	jal	6ac <waitpid>
 2e0:	85aa                	mv	a1,a0
    check("waitpid(pid2) - child exited", ret, 0);
 2e2:	4601                	li	a2,0
 2e4:	00001517          	auipc	a0,0x1
 2e8:	dc450513          	addi	a0,a0,-572 # 10a8 <malloc+0x5b8>
 2ec:	d15ff0ef          	jal	0 <check>
  }

  // Test 3: waitpid for init (pid 1) — should fail
  // (init never exits / caller is not init's parent)
  ret = waitpid(1);
 2f0:	4505                	li	a0,1
 2f2:	3ba000ef          	jal	6ac <waitpid>
 2f6:	85aa                	mv	a1,a0
  check("waitpid(1) - not our child", ret, -1);
 2f8:	567d                	li	a2,-1
 2fa:	00001517          	auipc	a0,0x1
 2fe:	dce50513          	addi	a0,a0,-562 # 10c8 <malloc+0x5d8>
 302:	cffff0ef          	jal	0 <check>

  // Test 4: waitpid for non-existent pid — should fail
  ret = waitpid(99);
 306:	06300513          	li	a0,99
 30a:	3a2000ef          	jal	6ac <waitpid>
 30e:	85aa                	mv	a1,a0
  check("waitpid(99) - no such process", ret, -1);
 310:	567d                	li	a2,-1
 312:	00001517          	auipc	a0,0x1
 316:	dd650513          	addi	a0,a0,-554 # 10e8 <malloc+0x5f8>
 31a:	ce7ff0ef          	jal	0 <check>

  printf("\n");
 31e:	00001517          	auipc	a0,0x1
 322:	9fa50513          	addi	a0,a0,-1542 # d18 <malloc+0x228>
 326:	716000ef          	jal	a3c <printf>

  // ============================================================
  printf("========== Summary ==========\n");
 32a:	00001517          	auipc	a0,0x1
 32e:	dde50513          	addi	a0,a0,-546 # 1108 <malloc+0x618>
 332:	70a000ef          	jal	a3c <printf>
  // ============================================================
  printf("Total: %d passed, %d failed\n", passed, failed);
 336:	00002617          	auipc	a2,0x2
 33a:	cca62603          	lw	a2,-822(a2) # 2000 <failed>
 33e:	00002597          	auipc	a1,0x2
 342:	cc65a583          	lw	a1,-826(a1) # 2004 <passed>
 346:	00001517          	auipc	a0,0x1
 34a:	de250513          	addi	a0,a0,-542 # 1128 <malloc+0x638>
 34e:	6ee000ef          	jal	a3c <printf>

  exit(0);
 352:	4501                	li	a0,0
 354:	298000ef          	jal	5ec <exit>

0000000000000358 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 358:	1141                	addi	sp,sp,-16
 35a:	e406                	sd	ra,8(sp)
 35c:	e022                	sd	s0,0(sp)
 35e:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 360:	cf3ff0ef          	jal	52 <main>
  exit(r);
 364:	288000ef          	jal	5ec <exit>

0000000000000368 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 368:	1141                	addi	sp,sp,-16
 36a:	e422                	sd	s0,8(sp)
 36c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 36e:	87aa                	mv	a5,a0
 370:	0585                	addi	a1,a1,1
 372:	0785                	addi	a5,a5,1
 374:	fff5c703          	lbu	a4,-1(a1)
 378:	fee78fa3          	sb	a4,-1(a5)
 37c:	fb75                	bnez	a4,370 <strcpy+0x8>
    ;
  return os;
}
 37e:	6422                	ld	s0,8(sp)
 380:	0141                	addi	sp,sp,16
 382:	8082                	ret

0000000000000384 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 384:	1141                	addi	sp,sp,-16
 386:	e422                	sd	s0,8(sp)
 388:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 38a:	00054783          	lbu	a5,0(a0)
 38e:	cb91                	beqz	a5,3a2 <strcmp+0x1e>
 390:	0005c703          	lbu	a4,0(a1)
 394:	00f71763          	bne	a4,a5,3a2 <strcmp+0x1e>
    p++, q++;
 398:	0505                	addi	a0,a0,1
 39a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 39c:	00054783          	lbu	a5,0(a0)
 3a0:	fbe5                	bnez	a5,390 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 3a2:	0005c503          	lbu	a0,0(a1)
}
 3a6:	40a7853b          	subw	a0,a5,a0
 3aa:	6422                	ld	s0,8(sp)
 3ac:	0141                	addi	sp,sp,16
 3ae:	8082                	ret

00000000000003b0 <strlen>:

uint
strlen(const char *s)
{
 3b0:	1141                	addi	sp,sp,-16
 3b2:	e422                	sd	s0,8(sp)
 3b4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 3b6:	00054783          	lbu	a5,0(a0)
 3ba:	cf91                	beqz	a5,3d6 <strlen+0x26>
 3bc:	0505                	addi	a0,a0,1
 3be:	87aa                	mv	a5,a0
 3c0:	86be                	mv	a3,a5
 3c2:	0785                	addi	a5,a5,1
 3c4:	fff7c703          	lbu	a4,-1(a5)
 3c8:	ff65                	bnez	a4,3c0 <strlen+0x10>
 3ca:	40a6853b          	subw	a0,a3,a0
 3ce:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 3d0:	6422                	ld	s0,8(sp)
 3d2:	0141                	addi	sp,sp,16
 3d4:	8082                	ret
  for(n = 0; s[n]; n++)
 3d6:	4501                	li	a0,0
 3d8:	bfe5                	j	3d0 <strlen+0x20>

00000000000003da <memset>:

void*
memset(void *dst, int c, uint n)
{
 3da:	1141                	addi	sp,sp,-16
 3dc:	e422                	sd	s0,8(sp)
 3de:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3e0:	ca19                	beqz	a2,3f6 <memset+0x1c>
 3e2:	87aa                	mv	a5,a0
 3e4:	1602                	slli	a2,a2,0x20
 3e6:	9201                	srli	a2,a2,0x20
 3e8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 3ec:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 3f0:	0785                	addi	a5,a5,1
 3f2:	fee79de3          	bne	a5,a4,3ec <memset+0x12>
  }
  return dst;
}
 3f6:	6422                	ld	s0,8(sp)
 3f8:	0141                	addi	sp,sp,16
 3fa:	8082                	ret

00000000000003fc <strchr>:

char*
strchr(const char *s, char c)
{
 3fc:	1141                	addi	sp,sp,-16
 3fe:	e422                	sd	s0,8(sp)
 400:	0800                	addi	s0,sp,16
  for(; *s; s++)
 402:	00054783          	lbu	a5,0(a0)
 406:	cb99                	beqz	a5,41c <strchr+0x20>
    if(*s == c)
 408:	00f58763          	beq	a1,a5,416 <strchr+0x1a>
  for(; *s; s++)
 40c:	0505                	addi	a0,a0,1
 40e:	00054783          	lbu	a5,0(a0)
 412:	fbfd                	bnez	a5,408 <strchr+0xc>
      return (char*)s;
  return 0;
 414:	4501                	li	a0,0
}
 416:	6422                	ld	s0,8(sp)
 418:	0141                	addi	sp,sp,16
 41a:	8082                	ret
  return 0;
 41c:	4501                	li	a0,0
 41e:	bfe5                	j	416 <strchr+0x1a>

0000000000000420 <gets>:

char*
gets(char *buf, int max)
{
 420:	711d                	addi	sp,sp,-96
 422:	ec86                	sd	ra,88(sp)
 424:	e8a2                	sd	s0,80(sp)
 426:	e4a6                	sd	s1,72(sp)
 428:	e0ca                	sd	s2,64(sp)
 42a:	fc4e                	sd	s3,56(sp)
 42c:	f852                	sd	s4,48(sp)
 42e:	f456                	sd	s5,40(sp)
 430:	f05a                	sd	s6,32(sp)
 432:	ec5e                	sd	s7,24(sp)
 434:	1080                	addi	s0,sp,96
 436:	8baa                	mv	s7,a0
 438:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 43a:	892a                	mv	s2,a0
 43c:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 43e:	4aa9                	li	s5,10
 440:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 442:	89a6                	mv	s3,s1
 444:	2485                	addiw	s1,s1,1
 446:	0344d663          	bge	s1,s4,472 <gets+0x52>
    cc = read(0, &c, 1);
 44a:	4605                	li	a2,1
 44c:	faf40593          	addi	a1,s0,-81
 450:	4501                	li	a0,0
 452:	1b2000ef          	jal	604 <read>
    if(cc < 1)
 456:	00a05e63          	blez	a0,472 <gets+0x52>
    buf[i++] = c;
 45a:	faf44783          	lbu	a5,-81(s0)
 45e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 462:	01578763          	beq	a5,s5,470 <gets+0x50>
 466:	0905                	addi	s2,s2,1
 468:	fd679de3          	bne	a5,s6,442 <gets+0x22>
    buf[i++] = c;
 46c:	89a6                	mv	s3,s1
 46e:	a011                	j	472 <gets+0x52>
 470:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 472:	99de                	add	s3,s3,s7
 474:	00098023          	sb	zero,0(s3)
  return buf;
}
 478:	855e                	mv	a0,s7
 47a:	60e6                	ld	ra,88(sp)
 47c:	6446                	ld	s0,80(sp)
 47e:	64a6                	ld	s1,72(sp)
 480:	6906                	ld	s2,64(sp)
 482:	79e2                	ld	s3,56(sp)
 484:	7a42                	ld	s4,48(sp)
 486:	7aa2                	ld	s5,40(sp)
 488:	7b02                	ld	s6,32(sp)
 48a:	6be2                	ld	s7,24(sp)
 48c:	6125                	addi	sp,sp,96
 48e:	8082                	ret

0000000000000490 <stat>:

int
stat(const char *n, struct stat *st)
{
 490:	1101                	addi	sp,sp,-32
 492:	ec06                	sd	ra,24(sp)
 494:	e822                	sd	s0,16(sp)
 496:	e04a                	sd	s2,0(sp)
 498:	1000                	addi	s0,sp,32
 49a:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 49c:	4581                	li	a1,0
 49e:	18e000ef          	jal	62c <open>
  if(fd < 0)
 4a2:	02054263          	bltz	a0,4c6 <stat+0x36>
 4a6:	e426                	sd	s1,8(sp)
 4a8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 4aa:	85ca                	mv	a1,s2
 4ac:	198000ef          	jal	644 <fstat>
 4b0:	892a                	mv	s2,a0
  close(fd);
 4b2:	8526                	mv	a0,s1
 4b4:	160000ef          	jal	614 <close>
  return r;
 4b8:	64a2                	ld	s1,8(sp)
}
 4ba:	854a                	mv	a0,s2
 4bc:	60e2                	ld	ra,24(sp)
 4be:	6442                	ld	s0,16(sp)
 4c0:	6902                	ld	s2,0(sp)
 4c2:	6105                	addi	sp,sp,32
 4c4:	8082                	ret
    return -1;
 4c6:	597d                	li	s2,-1
 4c8:	bfcd                	j	4ba <stat+0x2a>

00000000000004ca <atoi>:

int
atoi(const char *s)
{
 4ca:	1141                	addi	sp,sp,-16
 4cc:	e422                	sd	s0,8(sp)
 4ce:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 4d0:	00054683          	lbu	a3,0(a0)
 4d4:	fd06879b          	addiw	a5,a3,-48
 4d8:	0ff7f793          	zext.b	a5,a5
 4dc:	4625                	li	a2,9
 4de:	02f66863          	bltu	a2,a5,50e <atoi+0x44>
 4e2:	872a                	mv	a4,a0
  n = 0;
 4e4:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 4e6:	0705                	addi	a4,a4,1
 4e8:	0025179b          	slliw	a5,a0,0x2
 4ec:	9fa9                	addw	a5,a5,a0
 4ee:	0017979b          	slliw	a5,a5,0x1
 4f2:	9fb5                	addw	a5,a5,a3
 4f4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 4f8:	00074683          	lbu	a3,0(a4)
 4fc:	fd06879b          	addiw	a5,a3,-48
 500:	0ff7f793          	zext.b	a5,a5
 504:	fef671e3          	bgeu	a2,a5,4e6 <atoi+0x1c>
  return n;
}
 508:	6422                	ld	s0,8(sp)
 50a:	0141                	addi	sp,sp,16
 50c:	8082                	ret
  n = 0;
 50e:	4501                	li	a0,0
 510:	bfe5                	j	508 <atoi+0x3e>

0000000000000512 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 512:	1141                	addi	sp,sp,-16
 514:	e422                	sd	s0,8(sp)
 516:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 518:	02b57463          	bgeu	a0,a1,540 <memmove+0x2e>
    while(n-- > 0)
 51c:	00c05f63          	blez	a2,53a <memmove+0x28>
 520:	1602                	slli	a2,a2,0x20
 522:	9201                	srli	a2,a2,0x20
 524:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 528:	872a                	mv	a4,a0
      *dst++ = *src++;
 52a:	0585                	addi	a1,a1,1
 52c:	0705                	addi	a4,a4,1
 52e:	fff5c683          	lbu	a3,-1(a1)
 532:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 536:	fef71ae3          	bne	a4,a5,52a <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 53a:	6422                	ld	s0,8(sp)
 53c:	0141                	addi	sp,sp,16
 53e:	8082                	ret
    dst += n;
 540:	00c50733          	add	a4,a0,a2
    src += n;
 544:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 546:	fec05ae3          	blez	a2,53a <memmove+0x28>
 54a:	fff6079b          	addiw	a5,a2,-1
 54e:	1782                	slli	a5,a5,0x20
 550:	9381                	srli	a5,a5,0x20
 552:	fff7c793          	not	a5,a5
 556:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 558:	15fd                	addi	a1,a1,-1
 55a:	177d                	addi	a4,a4,-1
 55c:	0005c683          	lbu	a3,0(a1)
 560:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 564:	fee79ae3          	bne	a5,a4,558 <memmove+0x46>
 568:	bfc9                	j	53a <memmove+0x28>

000000000000056a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 56a:	1141                	addi	sp,sp,-16
 56c:	e422                	sd	s0,8(sp)
 56e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 570:	ca05                	beqz	a2,5a0 <memcmp+0x36>
 572:	fff6069b          	addiw	a3,a2,-1
 576:	1682                	slli	a3,a3,0x20
 578:	9281                	srli	a3,a3,0x20
 57a:	0685                	addi	a3,a3,1
 57c:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 57e:	00054783          	lbu	a5,0(a0)
 582:	0005c703          	lbu	a4,0(a1)
 586:	00e79863          	bne	a5,a4,596 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 58a:	0505                	addi	a0,a0,1
    p2++;
 58c:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 58e:	fed518e3          	bne	a0,a3,57e <memcmp+0x14>
  }
  return 0;
 592:	4501                	li	a0,0
 594:	a019                	j	59a <memcmp+0x30>
      return *p1 - *p2;
 596:	40e7853b          	subw	a0,a5,a4
}
 59a:	6422                	ld	s0,8(sp)
 59c:	0141                	addi	sp,sp,16
 59e:	8082                	ret
  return 0;
 5a0:	4501                	li	a0,0
 5a2:	bfe5                	j	59a <memcmp+0x30>

00000000000005a4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 5a4:	1141                	addi	sp,sp,-16
 5a6:	e406                	sd	ra,8(sp)
 5a8:	e022                	sd	s0,0(sp)
 5aa:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 5ac:	f67ff0ef          	jal	512 <memmove>
}
 5b0:	60a2                	ld	ra,8(sp)
 5b2:	6402                	ld	s0,0(sp)
 5b4:	0141                	addi	sp,sp,16
 5b6:	8082                	ret

00000000000005b8 <sbrk>:

char *
sbrk(int n) {
 5b8:	1141                	addi	sp,sp,-16
 5ba:	e406                	sd	ra,8(sp)
 5bc:	e022                	sd	s0,0(sp)
 5be:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 5c0:	4585                	li	a1,1
 5c2:	0b2000ef          	jal	674 <sys_sbrk>
}
 5c6:	60a2                	ld	ra,8(sp)
 5c8:	6402                	ld	s0,0(sp)
 5ca:	0141                	addi	sp,sp,16
 5cc:	8082                	ret

00000000000005ce <sbrklazy>:

char *
sbrklazy(int n) {
 5ce:	1141                	addi	sp,sp,-16
 5d0:	e406                	sd	ra,8(sp)
 5d2:	e022                	sd	s0,0(sp)
 5d4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 5d6:	4589                	li	a1,2
 5d8:	09c000ef          	jal	674 <sys_sbrk>
}
 5dc:	60a2                	ld	ra,8(sp)
 5de:	6402                	ld	s0,0(sp)
 5e0:	0141                	addi	sp,sp,16
 5e2:	8082                	ret

00000000000005e4 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 5e4:	4885                	li	a7,1
 ecall
 5e6:	00000073          	ecall
 ret
 5ea:	8082                	ret

00000000000005ec <exit>:
.global exit
exit:
 li a7, SYS_exit
 5ec:	4889                	li	a7,2
 ecall
 5ee:	00000073          	ecall
 ret
 5f2:	8082                	ret

00000000000005f4 <wait>:
.global wait
wait:
 li a7, SYS_wait
 5f4:	488d                	li	a7,3
 ecall
 5f6:	00000073          	ecall
 ret
 5fa:	8082                	ret

00000000000005fc <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 5fc:	4891                	li	a7,4
 ecall
 5fe:	00000073          	ecall
 ret
 602:	8082                	ret

0000000000000604 <read>:
.global read
read:
 li a7, SYS_read
 604:	4895                	li	a7,5
 ecall
 606:	00000073          	ecall
 ret
 60a:	8082                	ret

000000000000060c <write>:
.global write
write:
 li a7, SYS_write
 60c:	48c1                	li	a7,16
 ecall
 60e:	00000073          	ecall
 ret
 612:	8082                	ret

0000000000000614 <close>:
.global close
close:
 li a7, SYS_close
 614:	48d5                	li	a7,21
 ecall
 616:	00000073          	ecall
 ret
 61a:	8082                	ret

000000000000061c <kill>:
.global kill
kill:
 li a7, SYS_kill
 61c:	4899                	li	a7,6
 ecall
 61e:	00000073          	ecall
 ret
 622:	8082                	ret

0000000000000624 <exec>:
.global exec
exec:
 li a7, SYS_exec
 624:	489d                	li	a7,7
 ecall
 626:	00000073          	ecall
 ret
 62a:	8082                	ret

000000000000062c <open>:
.global open
open:
 li a7, SYS_open
 62c:	48bd                	li	a7,15
 ecall
 62e:	00000073          	ecall
 ret
 632:	8082                	ret

0000000000000634 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 634:	48c5                	li	a7,17
 ecall
 636:	00000073          	ecall
 ret
 63a:	8082                	ret

000000000000063c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 63c:	48c9                	li	a7,18
 ecall
 63e:	00000073          	ecall
 ret
 642:	8082                	ret

0000000000000644 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 644:	48a1                	li	a7,8
 ecall
 646:	00000073          	ecall
 ret
 64a:	8082                	ret

000000000000064c <link>:
.global link
link:
 li a7, SYS_link
 64c:	48cd                	li	a7,19
 ecall
 64e:	00000073          	ecall
 ret
 652:	8082                	ret

0000000000000654 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 654:	48d1                	li	a7,20
 ecall
 656:	00000073          	ecall
 ret
 65a:	8082                	ret

000000000000065c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 65c:	48a5                	li	a7,9
 ecall
 65e:	00000073          	ecall
 ret
 662:	8082                	ret

0000000000000664 <dup>:
.global dup
dup:
 li a7, SYS_dup
 664:	48a9                	li	a7,10
 ecall
 666:	00000073          	ecall
 ret
 66a:	8082                	ret

000000000000066c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 66c:	48ad                	li	a7,11
 ecall
 66e:	00000073          	ecall
 ret
 672:	8082                	ret

0000000000000674 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 674:	48b1                	li	a7,12
 ecall
 676:	00000073          	ecall
 ret
 67a:	8082                	ret

000000000000067c <pause>:
.global pause
pause:
 li a7, SYS_pause
 67c:	48b5                	li	a7,13
 ecall
 67e:	00000073          	ecall
 ret
 682:	8082                	ret

0000000000000684 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 684:	48b9                	li	a7,14
 ecall
 686:	00000073          	ecall
 ret
 68a:	8082                	ret

000000000000068c <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 68c:	48dd                	li	a7,23
 ecall
 68e:	00000073          	ecall
 ret
 692:	8082                	ret

0000000000000694 <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 694:	48e1                	li	a7,24
 ecall
 696:	00000073          	ecall
 ret
 69a:	8082                	ret

000000000000069c <ps>:
.global ps
ps:
 li a7, SYS_ps
 69c:	48e5                	li	a7,25
 ecall
 69e:	00000073          	ecall
 ret
 6a2:	8082                	ret

00000000000006a4 <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 6a4:	48e9                	li	a7,26
 ecall
 6a6:	00000073          	ecall
 ret
 6aa:	8082                	ret

00000000000006ac <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 6ac:	48ed                	li	a7,27
 ecall
 6ae:	00000073          	ecall
 ret
 6b2:	8082                	ret

00000000000006b4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6b4:	1101                	addi	sp,sp,-32
 6b6:	ec06                	sd	ra,24(sp)
 6b8:	e822                	sd	s0,16(sp)
 6ba:	1000                	addi	s0,sp,32
 6bc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 6c0:	4605                	li	a2,1
 6c2:	fef40593          	addi	a1,s0,-17
 6c6:	f47ff0ef          	jal	60c <write>
}
 6ca:	60e2                	ld	ra,24(sp)
 6cc:	6442                	ld	s0,16(sp)
 6ce:	6105                	addi	sp,sp,32
 6d0:	8082                	ret

00000000000006d2 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 6d2:	715d                	addi	sp,sp,-80
 6d4:	e486                	sd	ra,72(sp)
 6d6:	e0a2                	sd	s0,64(sp)
 6d8:	f84a                	sd	s2,48(sp)
 6da:	0880                	addi	s0,sp,80
 6dc:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 6de:	c299                	beqz	a3,6e4 <printint+0x12>
 6e0:	0805c363          	bltz	a1,766 <printint+0x94>
  neg = 0;
 6e4:	4881                	li	a7,0
 6e6:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 6ea:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 6ec:	00001517          	auipc	a0,0x1
 6f0:	a6450513          	addi	a0,a0,-1436 # 1150 <digits>
 6f4:	883e                	mv	a6,a5
 6f6:	2785                	addiw	a5,a5,1
 6f8:	02c5f733          	remu	a4,a1,a2
 6fc:	972a                	add	a4,a4,a0
 6fe:	00074703          	lbu	a4,0(a4)
 702:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 706:	872e                	mv	a4,a1
 708:	02c5d5b3          	divu	a1,a1,a2
 70c:	0685                	addi	a3,a3,1
 70e:	fec773e3          	bgeu	a4,a2,6f4 <printint+0x22>
  if(neg)
 712:	00088b63          	beqz	a7,728 <printint+0x56>
    buf[i++] = '-';
 716:	fd078793          	addi	a5,a5,-48
 71a:	97a2                	add	a5,a5,s0
 71c:	02d00713          	li	a4,45
 720:	fee78423          	sb	a4,-24(a5)
 724:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 728:	02f05a63          	blez	a5,75c <printint+0x8a>
 72c:	fc26                	sd	s1,56(sp)
 72e:	f44e                	sd	s3,40(sp)
 730:	fb840713          	addi	a4,s0,-72
 734:	00f704b3          	add	s1,a4,a5
 738:	fff70993          	addi	s3,a4,-1
 73c:	99be                	add	s3,s3,a5
 73e:	37fd                	addiw	a5,a5,-1
 740:	1782                	slli	a5,a5,0x20
 742:	9381                	srli	a5,a5,0x20
 744:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 748:	fff4c583          	lbu	a1,-1(s1)
 74c:	854a                	mv	a0,s2
 74e:	f67ff0ef          	jal	6b4 <putc>
  while(--i >= 0)
 752:	14fd                	addi	s1,s1,-1
 754:	ff349ae3          	bne	s1,s3,748 <printint+0x76>
 758:	74e2                	ld	s1,56(sp)
 75a:	79a2                	ld	s3,40(sp)
}
 75c:	60a6                	ld	ra,72(sp)
 75e:	6406                	ld	s0,64(sp)
 760:	7942                	ld	s2,48(sp)
 762:	6161                	addi	sp,sp,80
 764:	8082                	ret
    x = -xx;
 766:	40b005b3          	neg	a1,a1
    neg = 1;
 76a:	4885                	li	a7,1
    x = -xx;
 76c:	bfad                	j	6e6 <printint+0x14>

000000000000076e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 76e:	711d                	addi	sp,sp,-96
 770:	ec86                	sd	ra,88(sp)
 772:	e8a2                	sd	s0,80(sp)
 774:	e0ca                	sd	s2,64(sp)
 776:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 778:	0005c903          	lbu	s2,0(a1)
 77c:	28090663          	beqz	s2,a08 <vprintf+0x29a>
 780:	e4a6                	sd	s1,72(sp)
 782:	fc4e                	sd	s3,56(sp)
 784:	f852                	sd	s4,48(sp)
 786:	f456                	sd	s5,40(sp)
 788:	f05a                	sd	s6,32(sp)
 78a:	ec5e                	sd	s7,24(sp)
 78c:	e862                	sd	s8,16(sp)
 78e:	e466                	sd	s9,8(sp)
 790:	8b2a                	mv	s6,a0
 792:	8a2e                	mv	s4,a1
 794:	8bb2                	mv	s7,a2
  state = 0;
 796:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 798:	4481                	li	s1,0
 79a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 79c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 7a0:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7a4:	06c00c93          	li	s9,108
 7a8:	a005                	j	7c8 <vprintf+0x5a>
        putc(fd, c0);
 7aa:	85ca                	mv	a1,s2
 7ac:	855a                	mv	a0,s6
 7ae:	f07ff0ef          	jal	6b4 <putc>
 7b2:	a019                	j	7b8 <vprintf+0x4a>
    } else if(state == '%'){
 7b4:	03598263          	beq	s3,s5,7d8 <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 7b8:	2485                	addiw	s1,s1,1
 7ba:	8726                	mv	a4,s1
 7bc:	009a07b3          	add	a5,s4,s1
 7c0:	0007c903          	lbu	s2,0(a5)
 7c4:	22090a63          	beqz	s2,9f8 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 7c8:	0009079b          	sext.w	a5,s2
    if(state == 0){
 7cc:	fe0994e3          	bnez	s3,7b4 <vprintf+0x46>
      if(c0 == '%'){
 7d0:	fd579de3          	bne	a5,s5,7aa <vprintf+0x3c>
        state = '%';
 7d4:	89be                	mv	s3,a5
 7d6:	b7cd                	j	7b8 <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 7d8:	00ea06b3          	add	a3,s4,a4
 7dc:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 7e0:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 7e2:	c681                	beqz	a3,7ea <vprintf+0x7c>
 7e4:	9752                	add	a4,a4,s4
 7e6:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 7ea:	05878363          	beq	a5,s8,830 <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 7ee:	05978d63          	beq	a5,s9,848 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 7f2:	07500713          	li	a4,117
 7f6:	0ee78763          	beq	a5,a4,8e4 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 7fa:	07800713          	li	a4,120
 7fe:	12e78963          	beq	a5,a4,930 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 802:	07000713          	li	a4,112
 806:	14e78e63          	beq	a5,a4,962 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 80a:	06300713          	li	a4,99
 80e:	18e78e63          	beq	a5,a4,9aa <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 812:	07300713          	li	a4,115
 816:	1ae78463          	beq	a5,a4,9be <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 81a:	02500713          	li	a4,37
 81e:	04e79563          	bne	a5,a4,868 <vprintf+0xfa>
        putc(fd, '%');
 822:	02500593          	li	a1,37
 826:	855a                	mv	a0,s6
 828:	e8dff0ef          	jal	6b4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 82c:	4981                	li	s3,0
 82e:	b769                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 830:	008b8913          	addi	s2,s7,8
 834:	4685                	li	a3,1
 836:	4629                	li	a2,10
 838:	000ba583          	lw	a1,0(s7)
 83c:	855a                	mv	a0,s6
 83e:	e95ff0ef          	jal	6d2 <printint>
 842:	8bca                	mv	s7,s2
      state = 0;
 844:	4981                	li	s3,0
 846:	bf8d                	j	7b8 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 848:	06400793          	li	a5,100
 84c:	02f68963          	beq	a3,a5,87e <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 850:	06c00793          	li	a5,108
 854:	04f68263          	beq	a3,a5,898 <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 858:	07500793          	li	a5,117
 85c:	0af68063          	beq	a3,a5,8fc <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 860:	07800793          	li	a5,120
 864:	0ef68263          	beq	a3,a5,948 <vprintf+0x1da>
        putc(fd, '%');
 868:	02500593          	li	a1,37
 86c:	855a                	mv	a0,s6
 86e:	e47ff0ef          	jal	6b4 <putc>
        putc(fd, c0);
 872:	85ca                	mv	a1,s2
 874:	855a                	mv	a0,s6
 876:	e3fff0ef          	jal	6b4 <putc>
      state = 0;
 87a:	4981                	li	s3,0
 87c:	bf35                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 87e:	008b8913          	addi	s2,s7,8
 882:	4685                	li	a3,1
 884:	4629                	li	a2,10
 886:	000bb583          	ld	a1,0(s7)
 88a:	855a                	mv	a0,s6
 88c:	e47ff0ef          	jal	6d2 <printint>
        i += 1;
 890:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 892:	8bca                	mv	s7,s2
      state = 0;
 894:	4981                	li	s3,0
        i += 1;
 896:	b70d                	j	7b8 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 898:	06400793          	li	a5,100
 89c:	02f60763          	beq	a2,a5,8ca <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8a0:	07500793          	li	a5,117
 8a4:	06f60963          	beq	a2,a5,916 <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 8a8:	07800793          	li	a5,120
 8ac:	faf61ee3          	bne	a2,a5,868 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8b0:	008b8913          	addi	s2,s7,8
 8b4:	4681                	li	a3,0
 8b6:	4641                	li	a2,16
 8b8:	000bb583          	ld	a1,0(s7)
 8bc:	855a                	mv	a0,s6
 8be:	e15ff0ef          	jal	6d2 <printint>
        i += 2;
 8c2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8c4:	8bca                	mv	s7,s2
      state = 0;
 8c6:	4981                	li	s3,0
        i += 2;
 8c8:	bdc5                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8ca:	008b8913          	addi	s2,s7,8
 8ce:	4685                	li	a3,1
 8d0:	4629                	li	a2,10
 8d2:	000bb583          	ld	a1,0(s7)
 8d6:	855a                	mv	a0,s6
 8d8:	dfbff0ef          	jal	6d2 <printint>
        i += 2;
 8dc:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 8de:	8bca                	mv	s7,s2
      state = 0;
 8e0:	4981                	li	s3,0
        i += 2;
 8e2:	bdd9                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 8e4:	008b8913          	addi	s2,s7,8
 8e8:	4681                	li	a3,0
 8ea:	4629                	li	a2,10
 8ec:	000be583          	lwu	a1,0(s7)
 8f0:	855a                	mv	a0,s6
 8f2:	de1ff0ef          	jal	6d2 <printint>
 8f6:	8bca                	mv	s7,s2
      state = 0;
 8f8:	4981                	li	s3,0
 8fa:	bd7d                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 8fc:	008b8913          	addi	s2,s7,8
 900:	4681                	li	a3,0
 902:	4629                	li	a2,10
 904:	000bb583          	ld	a1,0(s7)
 908:	855a                	mv	a0,s6
 90a:	dc9ff0ef          	jal	6d2 <printint>
        i += 1;
 90e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 910:	8bca                	mv	s7,s2
      state = 0;
 912:	4981                	li	s3,0
        i += 1;
 914:	b555                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 916:	008b8913          	addi	s2,s7,8
 91a:	4681                	li	a3,0
 91c:	4629                	li	a2,10
 91e:	000bb583          	ld	a1,0(s7)
 922:	855a                	mv	a0,s6
 924:	dafff0ef          	jal	6d2 <printint>
        i += 2;
 928:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 92a:	8bca                	mv	s7,s2
      state = 0;
 92c:	4981                	li	s3,0
        i += 2;
 92e:	b569                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 930:	008b8913          	addi	s2,s7,8
 934:	4681                	li	a3,0
 936:	4641                	li	a2,16
 938:	000be583          	lwu	a1,0(s7)
 93c:	855a                	mv	a0,s6
 93e:	d95ff0ef          	jal	6d2 <printint>
 942:	8bca                	mv	s7,s2
      state = 0;
 944:	4981                	li	s3,0
 946:	bd8d                	j	7b8 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 948:	008b8913          	addi	s2,s7,8
 94c:	4681                	li	a3,0
 94e:	4641                	li	a2,16
 950:	000bb583          	ld	a1,0(s7)
 954:	855a                	mv	a0,s6
 956:	d7dff0ef          	jal	6d2 <printint>
        i += 1;
 95a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 95c:	8bca                	mv	s7,s2
      state = 0;
 95e:	4981                	li	s3,0
        i += 1;
 960:	bda1                	j	7b8 <vprintf+0x4a>
 962:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 964:	008b8d13          	addi	s10,s7,8
 968:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 96c:	03000593          	li	a1,48
 970:	855a                	mv	a0,s6
 972:	d43ff0ef          	jal	6b4 <putc>
  putc(fd, 'x');
 976:	07800593          	li	a1,120
 97a:	855a                	mv	a0,s6
 97c:	d39ff0ef          	jal	6b4 <putc>
 980:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 982:	00000b97          	auipc	s7,0x0
 986:	7ceb8b93          	addi	s7,s7,1998 # 1150 <digits>
 98a:	03c9d793          	srli	a5,s3,0x3c
 98e:	97de                	add	a5,a5,s7
 990:	0007c583          	lbu	a1,0(a5)
 994:	855a                	mv	a0,s6
 996:	d1fff0ef          	jal	6b4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 99a:	0992                	slli	s3,s3,0x4
 99c:	397d                	addiw	s2,s2,-1
 99e:	fe0916e3          	bnez	s2,98a <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 9a2:	8bea                	mv	s7,s10
      state = 0;
 9a4:	4981                	li	s3,0
 9a6:	6d02                	ld	s10,0(sp)
 9a8:	bd01                	j	7b8 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 9aa:	008b8913          	addi	s2,s7,8
 9ae:	000bc583          	lbu	a1,0(s7)
 9b2:	855a                	mv	a0,s6
 9b4:	d01ff0ef          	jal	6b4 <putc>
 9b8:	8bca                	mv	s7,s2
      state = 0;
 9ba:	4981                	li	s3,0
 9bc:	bbf5                	j	7b8 <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 9be:	008b8993          	addi	s3,s7,8
 9c2:	000bb903          	ld	s2,0(s7)
 9c6:	00090f63          	beqz	s2,9e4 <vprintf+0x276>
        for(; *s; s++)
 9ca:	00094583          	lbu	a1,0(s2)
 9ce:	c195                	beqz	a1,9f2 <vprintf+0x284>
          putc(fd, *s);
 9d0:	855a                	mv	a0,s6
 9d2:	ce3ff0ef          	jal	6b4 <putc>
        for(; *s; s++)
 9d6:	0905                	addi	s2,s2,1
 9d8:	00094583          	lbu	a1,0(s2)
 9dc:	f9f5                	bnez	a1,9d0 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 9de:	8bce                	mv	s7,s3
      state = 0;
 9e0:	4981                	li	s3,0
 9e2:	bbd9                	j	7b8 <vprintf+0x4a>
          s = "(null)";
 9e4:	00000917          	auipc	s2,0x0
 9e8:	76490913          	addi	s2,s2,1892 # 1148 <malloc+0x658>
        for(; *s; s++)
 9ec:	02800593          	li	a1,40
 9f0:	b7c5                	j	9d0 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 9f2:	8bce                	mv	s7,s3
      state = 0;
 9f4:	4981                	li	s3,0
 9f6:	b3c9                	j	7b8 <vprintf+0x4a>
 9f8:	64a6                	ld	s1,72(sp)
 9fa:	79e2                	ld	s3,56(sp)
 9fc:	7a42                	ld	s4,48(sp)
 9fe:	7aa2                	ld	s5,40(sp)
 a00:	7b02                	ld	s6,32(sp)
 a02:	6be2                	ld	s7,24(sp)
 a04:	6c42                	ld	s8,16(sp)
 a06:	6ca2                	ld	s9,8(sp)
    }
  }
}
 a08:	60e6                	ld	ra,88(sp)
 a0a:	6446                	ld	s0,80(sp)
 a0c:	6906                	ld	s2,64(sp)
 a0e:	6125                	addi	sp,sp,96
 a10:	8082                	ret

0000000000000a12 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a12:	715d                	addi	sp,sp,-80
 a14:	ec06                	sd	ra,24(sp)
 a16:	e822                	sd	s0,16(sp)
 a18:	1000                	addi	s0,sp,32
 a1a:	e010                	sd	a2,0(s0)
 a1c:	e414                	sd	a3,8(s0)
 a1e:	e818                	sd	a4,16(s0)
 a20:	ec1c                	sd	a5,24(s0)
 a22:	03043023          	sd	a6,32(s0)
 a26:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a2a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a2e:	8622                	mv	a2,s0
 a30:	d3fff0ef          	jal	76e <vprintf>
}
 a34:	60e2                	ld	ra,24(sp)
 a36:	6442                	ld	s0,16(sp)
 a38:	6161                	addi	sp,sp,80
 a3a:	8082                	ret

0000000000000a3c <printf>:

void
printf(const char *fmt, ...)
{
 a3c:	711d                	addi	sp,sp,-96
 a3e:	ec06                	sd	ra,24(sp)
 a40:	e822                	sd	s0,16(sp)
 a42:	1000                	addi	s0,sp,32
 a44:	e40c                	sd	a1,8(s0)
 a46:	e810                	sd	a2,16(s0)
 a48:	ec14                	sd	a3,24(s0)
 a4a:	f018                	sd	a4,32(s0)
 a4c:	f41c                	sd	a5,40(s0)
 a4e:	03043823          	sd	a6,48(s0)
 a52:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a56:	00840613          	addi	a2,s0,8
 a5a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a5e:	85aa                	mv	a1,a0
 a60:	4505                	li	a0,1
 a62:	d0dff0ef          	jal	76e <vprintf>
}
 a66:	60e2                	ld	ra,24(sp)
 a68:	6442                	ld	s0,16(sp)
 a6a:	6125                	addi	sp,sp,96
 a6c:	8082                	ret

0000000000000a6e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a6e:	1141                	addi	sp,sp,-16
 a70:	e422                	sd	s0,8(sp)
 a72:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a74:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a78:	00001797          	auipc	a5,0x1
 a7c:	5907b783          	ld	a5,1424(a5) # 2008 <freep>
 a80:	a02d                	j	aaa <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 a82:	4618                	lw	a4,8(a2)
 a84:	9f2d                	addw	a4,a4,a1
 a86:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a8a:	6398                	ld	a4,0(a5)
 a8c:	6310                	ld	a2,0(a4)
 a8e:	a83d                	j	acc <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 a90:	ff852703          	lw	a4,-8(a0)
 a94:	9f31                	addw	a4,a4,a2
 a96:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a98:	ff053683          	ld	a3,-16(a0)
 a9c:	a091                	j	ae0 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a9e:	6398                	ld	a4,0(a5)
 aa0:	00e7e463          	bltu	a5,a4,aa8 <free+0x3a>
 aa4:	00e6ea63          	bltu	a3,a4,ab8 <free+0x4a>
{
 aa8:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 aaa:	fed7fae3          	bgeu	a5,a3,a9e <free+0x30>
 aae:	6398                	ld	a4,0(a5)
 ab0:	00e6e463          	bltu	a3,a4,ab8 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ab4:	fee7eae3          	bltu	a5,a4,aa8 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 ab8:	ff852583          	lw	a1,-8(a0)
 abc:	6390                	ld	a2,0(a5)
 abe:	02059813          	slli	a6,a1,0x20
 ac2:	01c85713          	srli	a4,a6,0x1c
 ac6:	9736                	add	a4,a4,a3
 ac8:	fae60de3          	beq	a2,a4,a82 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 acc:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 ad0:	4790                	lw	a2,8(a5)
 ad2:	02061593          	slli	a1,a2,0x20
 ad6:	01c5d713          	srli	a4,a1,0x1c
 ada:	973e                	add	a4,a4,a5
 adc:	fae68ae3          	beq	a3,a4,a90 <free+0x22>
    p->s.ptr = bp->s.ptr;
 ae0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 ae2:	00001717          	auipc	a4,0x1
 ae6:	52f73323          	sd	a5,1318(a4) # 2008 <freep>
}
 aea:	6422                	ld	s0,8(sp)
 aec:	0141                	addi	sp,sp,16
 aee:	8082                	ret

0000000000000af0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 af0:	7139                	addi	sp,sp,-64
 af2:	fc06                	sd	ra,56(sp)
 af4:	f822                	sd	s0,48(sp)
 af6:	f426                	sd	s1,40(sp)
 af8:	ec4e                	sd	s3,24(sp)
 afa:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 afc:	02051493          	slli	s1,a0,0x20
 b00:	9081                	srli	s1,s1,0x20
 b02:	04bd                	addi	s1,s1,15
 b04:	8091                	srli	s1,s1,0x4
 b06:	0014899b          	addiw	s3,s1,1
 b0a:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 b0c:	00001517          	auipc	a0,0x1
 b10:	4fc53503          	ld	a0,1276(a0) # 2008 <freep>
 b14:	c915                	beqz	a0,b48 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b16:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b18:	4798                	lw	a4,8(a5)
 b1a:	08977a63          	bgeu	a4,s1,bae <malloc+0xbe>
 b1e:	f04a                	sd	s2,32(sp)
 b20:	e852                	sd	s4,16(sp)
 b22:	e456                	sd	s5,8(sp)
 b24:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 b26:	8a4e                	mv	s4,s3
 b28:	0009871b          	sext.w	a4,s3
 b2c:	6685                	lui	a3,0x1
 b2e:	00d77363          	bgeu	a4,a3,b34 <malloc+0x44>
 b32:	6a05                	lui	s4,0x1
 b34:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b38:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b3c:	00001917          	auipc	s2,0x1
 b40:	4cc90913          	addi	s2,s2,1228 # 2008 <freep>
  if(p == SBRK_ERROR)
 b44:	5afd                	li	s5,-1
 b46:	a081                	j	b86 <malloc+0x96>
 b48:	f04a                	sd	s2,32(sp)
 b4a:	e852                	sd	s4,16(sp)
 b4c:	e456                	sd	s5,8(sp)
 b4e:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 b50:	00001797          	auipc	a5,0x1
 b54:	4c078793          	addi	a5,a5,1216 # 2010 <base>
 b58:	00001717          	auipc	a4,0x1
 b5c:	4af73823          	sd	a5,1200(a4) # 2008 <freep>
 b60:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b62:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b66:	b7c1                	j	b26 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 b68:	6398                	ld	a4,0(a5)
 b6a:	e118                	sd	a4,0(a0)
 b6c:	a8a9                	j	bc6 <malloc+0xd6>
  hp->s.size = nu;
 b6e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b72:	0541                	addi	a0,a0,16
 b74:	efbff0ef          	jal	a6e <free>
  return freep;
 b78:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 b7c:	c12d                	beqz	a0,bde <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b7e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b80:	4798                	lw	a4,8(a5)
 b82:	02977263          	bgeu	a4,s1,ba6 <malloc+0xb6>
    if(p == freep)
 b86:	00093703          	ld	a4,0(s2)
 b8a:	853e                	mv	a0,a5
 b8c:	fef719e3          	bne	a4,a5,b7e <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 b90:	8552                	mv	a0,s4
 b92:	a27ff0ef          	jal	5b8 <sbrk>
  if(p == SBRK_ERROR)
 b96:	fd551ce3          	bne	a0,s5,b6e <malloc+0x7e>
        return 0;
 b9a:	4501                	li	a0,0
 b9c:	7902                	ld	s2,32(sp)
 b9e:	6a42                	ld	s4,16(sp)
 ba0:	6aa2                	ld	s5,8(sp)
 ba2:	6b02                	ld	s6,0(sp)
 ba4:	a03d                	j	bd2 <malloc+0xe2>
 ba6:	7902                	ld	s2,32(sp)
 ba8:	6a42                	ld	s4,16(sp)
 baa:	6aa2                	ld	s5,8(sp)
 bac:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 bae:	fae48de3          	beq	s1,a4,b68 <malloc+0x78>
        p->s.size -= nunits;
 bb2:	4137073b          	subw	a4,a4,s3
 bb6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 bb8:	02071693          	slli	a3,a4,0x20
 bbc:	01c6d713          	srli	a4,a3,0x1c
 bc0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 bc2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 bc6:	00001717          	auipc	a4,0x1
 bca:	44a73123          	sd	a0,1090(a4) # 2008 <freep>
      return (void*)(p + 1);
 bce:	01078513          	addi	a0,a5,16
  }
}
 bd2:	70e2                	ld	ra,56(sp)
 bd4:	7442                	ld	s0,48(sp)
 bd6:	74a2                	ld	s1,40(sp)
 bd8:	69e2                	ld	s3,24(sp)
 bda:	6121                	addi	sp,sp,64
 bdc:	8082                	ret
 bde:	7902                	ld	s2,32(sp)
 be0:	6a42                	ld	s4,16(sp)
 be2:	6aa2                	ld	s5,8(sp)
 be4:	6b02                	ld	s6,0(sp)
 be6:	b7f5                	j	bd2 <malloc+0xe2>
